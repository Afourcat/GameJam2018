﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
    
public class BoardManager : MonoBehaviour {

    [Serializable]
    public class Count
    {
        public int minimum;
        public int maximum;

        public Count (int max, int min)
        {
            minimum = min;
            maximum = max;

        }
    }

    private GameObject exit;
    private GameObject[] grassTiles;
    private GameObject[] wallTiles;

    private Transform boardHolder;
    private List<Vector3> gridPosition = new List<Vector3>();




	// Use this for initialization
	void Start () {
        wall[i] = GetComponent<GameObject>.wallTiles
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
