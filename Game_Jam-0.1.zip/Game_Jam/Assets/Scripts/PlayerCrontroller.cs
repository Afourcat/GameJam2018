﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

[System.Serializable]
public class Done_Boundary
{
    public float xMin, xMax, yMin, yMax;
}

public class PlayerCrontroller : MonoBehaviour {

    public float speed;
    public float tilt;
    public Done_Boundary boundary;

    private Rigidbody2D rb2d;
    
	// Update is called once per frame
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
	}

    void FixedUpdate ()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector2 move = new Vector2(moveHorizontal, moveVertical);
        rb2d.velocity = move * speed;

        //Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        //GetComponent<Rigidbody2D>().velocity = movement * speed;

        //GetComponent<Rigidbody2D>().position = new Vector3 ( Mathf.Clamp(GetComponent<Rigidbody2D>().position.x, boundary.xMin, boundary.xMax), 0.0f, Mathf.Clamp(GetComponent<Rigidbody2D>().position.y, boundary.yMin, boundary.yMax));
    }
}
